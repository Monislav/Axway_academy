﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CountriesAsssistant.Data.Models
{
    public class Country
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        public string CallingCode { get; set; }

        public string Capital { get; set; }

        public string Region { get; set; }

        public string SubRegion { get; set; }

        public double AreaInSquareKm { get; set; }

        public long Population { get; set; }

        public virtual ICollection<Currency> Currencies { get; set;  } = new HashSet<Currency>();
    }
}
