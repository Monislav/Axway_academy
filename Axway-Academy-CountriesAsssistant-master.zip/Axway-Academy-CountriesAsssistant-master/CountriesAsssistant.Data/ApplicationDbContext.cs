﻿using CountriesAsssistant.Data.Models;
using System.Data.Entity;

namespace CountriesAsssistant.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext()
            : base("DefaultConnection")
        {
        }

        public IDbSet<Currency> Currencies { get; set; }

        public IDbSet<Country> Countries { get; set; }
    }
}
