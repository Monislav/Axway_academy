﻿namespace CountriesAsssistant.Models
{
    public class CreateCurrencyDto
    {
        public string CurrencyName { get; set; }
        public string CountryName { get; set; }
    }
}
