﻿namespace CountriesAsssistant.Services.Interfaces
{
    using CountriesAsssistant.Models;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface ICurrencyService
    {
        Task<IEnumerable<CurrencyDto>> GetAll(int page, int pageSize);

        Task<CurrencyDto> GetBy(int id);

        Task<IEnumerable<CurrencyDto>> GetByCountry(int id);
         
        Task<IEnumerable<CurrencyDto>> GetByCountry(string country);

        Task<CurrencyDto> AddCurrency(CreateCurrencyDto createCurrencyDto);
    }
}
