﻿namespace CountriesAsssistant.Services.Interfaces
{
    using CountriesAsssistant.Models;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface ICountryService
    {
        Task<IEnumerable<DetailedCountryDto>> GetAll(int page, int pageSize);

        Task<IEnumerable<DetailedCountryDto>> GetById(int id);
    }
}
