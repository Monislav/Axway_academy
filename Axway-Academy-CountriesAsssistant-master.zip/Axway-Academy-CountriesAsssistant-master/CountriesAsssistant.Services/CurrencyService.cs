﻿namespace CountriesAsssistant.Services
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using AutoMapper.QueryableExtensions;
    using CountriesAsssistant.Data;
    using CountriesAsssistant.Data.Models;
    using CountriesAsssistant.Models;
    using CountriesAsssistant.Services.Interfaces;

    public class CurrencyService : ICurrencyService
    {
        private readonly ApplicationDbContext dbContext;

        public CurrencyService(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<CurrencyDto> AddCurrency(CreateCurrencyDto createCurrencyDto)
        {
            var dbCountry = await this.dbContext.Countries
                .Where(c => c.Name == createCurrencyDto.CountryName)
                .FirstOrDefaultAsync();
            if (dbCountry == null)
            {
                throw new InvalidOperationException($"Country {createCurrencyDto.CountryName} does not exist!");
            }

            var dbCurrency = new Currency
            {
                Name = createCurrencyDto.CurrencyName,
                Country = dbCountry,
            };
            this.dbContext.Currencies.Add(dbCurrency);
            await this.dbContext.SaveChangesAsync();

            return Mapper.Map<CurrencyDto>(dbCurrency);
        }

        public async Task<IEnumerable<CurrencyDto>> GetAll(int page, int pageSize)
        {
            var allCurrencies = this.dbContext.Currencies
                .OrderBy(x => x.Name)
                .Skip(pageSize * (page - 1))
                .Take(pageSize);

            return await allCurrencies
                .ProjectTo<CurrencyDto>()
                .ToListAsync();
        }

        public async Task<CurrencyDto> GetBy(int id)
        {
            var currency = await this.dbContext.Currencies
                .Where(c => c.CountryId == id)
                .ProjectTo<CurrencyDto>()
                .SingleOrDefaultAsync();

            return currency;
        }

        public async Task<IEnumerable<CurrencyDto>> GetByCountry(int id)
        {
            var allCurrencies = await this.dbContext.Currencies
                .Where(c => c.CountryId == id)
                .ProjectTo<CurrencyDto>()
                .ToListAsync();

            return allCurrencies;
        }

        public async Task<IEnumerable<CurrencyDto>> GetByCountry(string country)
        {
            var countryId = await this.dbContext.Currencies
                .Where(c => c.Country.Name == country)
                .Select(x => x.Id)
                .SingleOrDefaultAsync();

            return await this.GetByCountry(countryId);
        }
    }
}
