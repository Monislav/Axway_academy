﻿namespace CountriesAsssistant.Services
{
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper.QueryableExtensions;
    using CountriesAsssistant.Data;
    using CountriesAsssistant.Models;
    using CountriesAsssistant.Services.Interfaces;

    public class CountryService : ICountryService
    {
        private readonly ApplicationDbContext dbContext;

        public CountryService(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;

        }
        public async Task<IEnumerable<DetailedCountryDto>> GetAll(int page, int pageSize)
        {
            var allCountries = this.dbContext.Countries
                .OrderBy(x => x.Name)
                .Skip(pageSize * (page - 1))
                .Take(pageSize);

            return await allCountries
                .ProjectTo<DetailedCountryDto>()
                .ToListAsync();
        }

        public async Task<IEnumerable<DetailedCountryDto>> GetById(int id)
        {
            return await this.dbContext.Countries
                 .Where(c => c.Id == id)
                 .ProjectTo<DetailedCountryDto>()
                 .ToListAsync();
        }
    }
}
