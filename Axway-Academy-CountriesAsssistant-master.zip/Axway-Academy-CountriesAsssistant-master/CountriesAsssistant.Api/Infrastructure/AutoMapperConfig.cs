﻿using AutoMapper;
using CountriesAsssistant.Data.Models;
using CountriesAsssistant.Models;

namespace CountriesAsssistant.Api.Infrastructure
{
    public class AutoMapperConfig
    {
        public static void Initialize()
        {
            Mapper.Initialize((config) =>
            {
                config.CreateMap<Currency, CurrencyDto>().ReverseMap();
                config.CreateMap<Country, DetailedCountryDto>().ReverseMap();
            });
        }
    }
}
