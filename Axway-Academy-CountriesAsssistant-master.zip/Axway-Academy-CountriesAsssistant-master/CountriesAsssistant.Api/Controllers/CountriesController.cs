﻿namespace CountriesAsssistant.Api.Controllers
{
    using CountriesAsssistant.Services.Interfaces;
    using System.Threading.Tasks;
    using System.Web.Http;

    public class CountriesController : ApiController
    {
        private readonly ICountryService countryService;

        public CountriesController(ICountryService countryService)
        {
            this.countryService = countryService;
        }

        public async Task<IHttpActionResult> Get()
        {
            var result = await this.countryService.GetAll(1, 10);
            return Ok(result);
        }
    }
}
