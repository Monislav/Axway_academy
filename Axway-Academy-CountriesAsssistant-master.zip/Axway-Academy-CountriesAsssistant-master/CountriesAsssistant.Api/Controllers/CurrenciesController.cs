﻿using CountriesAsssistant.Models;
using CountriesAsssistant.Services.Interfaces;
using System;
using System.Threading.Tasks;
using System.Web.Http;

namespace CountriesAsssistant.Api.Controllers
{
    [RoutePrefix("currencies")]
    public class CurrenciesController : ApiController
    {
        private readonly ICurrencyService currencyService;
        
        public CurrenciesController(ICurrencyService currencyService)
        {
            this.currencyService = currencyService;
        }

        [HttpGet, Route("")]
        public async Task<IHttpActionResult> Get()
        {
            var result = await this.currencyService.GetAll(1, 10);
            return Ok(result);
        }

        [HttpGet, Route("{id}", Name = nameof(GetById))]
        public async Task<IHttpActionResult> GetById(int id)
        {
            var result = await this.currencyService.GetBy(id);
            return Ok(result);
        }

        [HttpGet, Route("by-country/{countryName}")]
        public async Task<IHttpActionResult> GetByCountry(string countryName)
        {
            var result = await this.currencyService.GetByCountry(countryName);
            return Ok(result);
        }
        
        [HttpPost, Route("add")]
        public async Task<IHttpActionResult> Post(CreateCurrencyDto model)
        {
            if (model?.CountryName == null || model?.CountryName == null)
            {
                return this.BadRequest("Model fields cannot be null.");
            }

            var createdCurrency = await this.currencyService.AddCurrency(model);

            return CreatedAtRoute(nameof(GetById), new { id = createdCurrency.Id}, createdCurrency);
        }
    }
}
