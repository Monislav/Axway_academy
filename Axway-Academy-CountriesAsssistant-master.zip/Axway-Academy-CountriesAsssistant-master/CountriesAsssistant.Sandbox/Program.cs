﻿using CountriesAsssistant.Data;
using CountriesAsssistant.Data.Models;
using Flurl.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CountriesAsssistant.Sandbox
{
    class Program
    {
        static void Main(string[] args)
        {
            var headers = new Dictionary<string, string>()
            {
                { "X-RapidAPI-Host", "restcountries-v1.p.rapidapi.com"},
                { "X-RapidAPI-Key", "8c568ebb17mshcec75f79527c219p19b245jsn43617cf92f71"},
            };

            var allCountries = GetCountriesData().GetAwaiter().GetResult();
            SeedData(allCountries);
            Console.ReadLine();
        }

        private static void SeedData(List<ApiCountry> allCountries)
        {
            Console.WriteLine("Seeding data in database...");
            int index = 0;
            using (var db = new ApplicationDbContext())
            {
                foreach (var apiCountry in allCountries)
                {
                    var country = new Country
                    {
                        Name = apiCountry.Name,
                        AreaInSquareKm = apiCountry.AreaInSquareKm,
                        CallingCode = apiCountry.CallingCode,
                        Capital = apiCountry.Capital,
                        Population = apiCountry.Population,
                        Region = apiCountry.Region,
                        SubRegion = apiCountry.SubRegion,
                    };
                    country.Currencies = apiCountry.Currencies
                        .Select(x => new Currency { Name = x, CountryId = country.Id })
                        .ToList();

                    db.Countries.Add(country);
                    db.SaveChanges();
                    index += 1;
                    if (index % 10 == 0)
                    {
                        Console.Write("#");
                    }
                }
            }
            Console.WriteLine();
            Console.WriteLine("Done");
        }

        static async Task<List<ApiCountry>> GetCountriesData()
        {
            const string ApiUrl = "https://restcountries-v1.p.rapidapi.com/all";
            Console.WriteLine($"Calling {ApiUrl} ...");
            var res = await ApiUrl
               .WithHeader("X-RapidAPI-Host", "restcountries-v1.p.rapidapi.com")
               .WithHeader("X-RapidAPI-Key", "8c568ebb17mshcec75f79527c219p19b245jsn43617cf92f71")
               .GetJsonAsync<List<ApiCountry>>();
            Console.WriteLine($"Response received {res.Count()} records were returned.");
            return res;
        }
    }
}
