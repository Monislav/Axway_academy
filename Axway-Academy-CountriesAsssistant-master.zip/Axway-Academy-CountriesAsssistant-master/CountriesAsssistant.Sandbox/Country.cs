﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CountriesAsssistant.Sandbox
{
    public class ApiCountry
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string CallingCode { get; set; }
        public string Capital { get; set; }
        public string Region { get; set; }
        public string SubRegion { get; set; }
        public int MyProperty { get; set; }
        public double AreaInSquareKm { get; set; }
        public long Population { get; set; }

        public string[] Currencies { get; set; }
    }

    public class ApiCurrency
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public int CountryId { get; set; }
    }
}