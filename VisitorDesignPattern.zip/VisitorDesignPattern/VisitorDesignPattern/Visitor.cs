﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VisitorDesignPattern
{
    interface IVisitor
    {
        int Visit(Year carYear);
        string Visit(Brand carBrand);
        double Visit(Price carPrice);
        string Visit(Color carColor);
    }
}
