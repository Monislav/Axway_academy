﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VisitorDesignPattern
{
    class Year : IAccept
    {
        public int year;
        public Year(int num)
        {
            year = num;
        }

        public int getYear()
        {
            return year;
        }

        public int Accept(IVisitor visitor)
        {
            return visitor.Visit(this);
        }

        public string strAccept(IVisitor visitor)
        {
            return "";
        }

        public double dbAccept(IVisitor visitor)
        {
            return 0;
        }
    }
}
