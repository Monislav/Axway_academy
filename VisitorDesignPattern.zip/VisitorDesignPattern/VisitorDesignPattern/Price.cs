﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VisitorDesignPattern
{
    class Price : IAccept
    {
        public double price;
        public Price(double num)
        {
            price = num;
        }
        public double getPrice()
        {
            return price;
        }
        public int Accept(IVisitor visitor)
        {
            return 0;
        }

        public double dbAccept(IVisitor visitor)
        {
            return visitor.Visit(this);
        }

        public string strAccept(IVisitor visitor)
        {
            return "";
        }
    }
}
