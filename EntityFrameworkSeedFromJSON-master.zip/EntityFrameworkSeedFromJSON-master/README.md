# EntityFrameworkSeedFromJSON
How to take a JSON file and include it in a Visual Studio 2015 Console project that includes Entity Framework 6 and seed that Data (from the JSON file)

Blog Posts With More Details About this Project

http://peterkellner.net/2015/11/10/github-visual-studio-2015-extension-getting-started/

http://peterkellner.net/2015/11/10/seed-entity-framework-code-first-with-json-using-c-dynamic/

http://peterkellner.net/2015/11/11/seeding-a-many-to-many-with-entity-framework-and-c-dynamic/
