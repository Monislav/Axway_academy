﻿using WPF_Client_Web_API.Helper_Code.Common;
using WPF_Client_Web_API.Helper_Code.Objects;
using WPF_Client_Web_API.Model.BusinessLogic.Helper_Code.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_Client_Web_API.Views
{
    /// <summary>
    /// Interaction logic for HomePage.xaml
    /// </summary>
    public partial class HomePage : Page
    {
        public HomePage()
        {
            InitializeComponent();
        }

        private async void BtnReg_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Initialization.
                string fullname = this.txtName.Text, obj;

                // Save Info to Local DB.
                HomeBusinessLogic.saveInfo(fullname);

                // Sending data to server.
                RegInfoRequestObj requestObj = new RegInfoRequestObj { fullname = fullname };
                RegInfoResponseObj responseObj = await HomeBusinessLogic.PostRegInfo(requestObj);

                // Veerification.
                if (responseObj.code == 600)
                {
                    // Display Message
                    MessageBox.Show("You are Successfully! Registered", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else if (responseObj.code == 602)
                {
                    // Display Message
                    MessageBox.Show("We are unable to register you at the moment, please try again later", "Fail", MessageBoxButton.OK, MessageBoxImage.Error);
                }

            }
            catch (Exception ex)
            {
                // Display Message
                MessageBox.Show("Something goes wrong, Please try again later.", "Fail", MessageBoxButton.OK, MessageBoxImage.Error);

                Console.Write(ex);
            }
        }
    }
}
