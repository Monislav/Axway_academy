﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_Client_Web_API.Helper_Code.Objects
{
    public class RegInfoRequestObj
    {
        public string fullname { get; set; }
    }
}
