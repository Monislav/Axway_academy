﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;
using RestWebApiServer.Helper_Code.Objects;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestWebApiServer.Models;

namespace RestWebApiServer.Controllers
{
    public class WebApiController : ApiController
    {
        // GET api/WebApi/PostRegInfo
        [Route("api/WebApi/PostRegInfo")]
        [HttpPost]
        public HttpResponseMessage GetValById([FromBody]JToken postData, HttpRequestMessage request)
        {
            // Initialization
            HttpResponseMessage response = null;
            RegInfoRequestObj requestObj = JsonConvert.DeserializeObject<RegInfoRequestObj>(postData.ToString());
            RegInfoResponseObj responseObj = new RegInfoResponseObj();
            string json = string.Empty;
            WpfWalkthrough_ServerEntities dbManager = new WpfWalkthrough_ServerEntities();

            try
            {
                // Query.
                string query = "INSERT INTO [Register] ([fullname])" +
                                " Values ('" + requestObj.fullname + "')";

                // Inserting.
                dbManager.Database.ExecuteSqlCommand(query);
                dbManager.SaveChanges();

                // Settings.
                json = JsonConvert.SerializeObject(new RegInfoResponseObj { status = true, code = 600, message = "Information successfully! saved" });
                response = Request.CreateResponse(HttpStatusCode.OK);
                response.Content = new StringContent(json, Encoding.UTF8, "application/json");
            }
            catch (Exception ex)
            {
                // Setting.
                json = JsonConvert.SerializeObject(new RegInfoResponseObj { status = false, code = 602, message = ex.Message });
                response = Request.CreateResponse(HttpStatusCode.OK);
                response.Content = new StringContent(json, Encoding.UTF8, "application/json");

                // info.
                Console.Write(ex);
            }

            // Info.
            return response;
        }
    }
}