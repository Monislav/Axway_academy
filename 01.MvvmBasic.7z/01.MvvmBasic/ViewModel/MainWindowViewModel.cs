﻿using System;
using System.ComponentModel;
using System.Windows.Input;
using System.Windows.Media;

using _02.NotifyPropertyChanged;

namespace _01.MvvmBasic.ViewModel
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        private const int DANGER_LIMIT = 0;

        private int counter;

        private Brush counterBackground;

        public event PropertyChangedEventHandler PropertyChanged;

        public int Counter
        {
            get { return this.counter; }
            set
            {
                this.counter = value;
                this.RaiseEvent(nameof(this.Counter));
            }
        }

        public Brush CounterBackground
        {
            get { return this.counterBackground; }
            set
            {
                this.counterBackground = value;
                this.RaiseEvent(nameof(this.CounterBackground));
            }
        }

        public ICommand IncrementCommand { get; set; }
        public ICommand DecrementCommand { get; set; }

        public MainWindowViewModel()
        {
            this.counter = 0;
            this.counterBackground = Brushes.Transparent;
            this.IncrementCommand = new LambdaCommand(this.OnIncrementClick);
            this.DecrementCommand = new LambdaCommand(this.OnDecrementClick);
            this.CheckColor();
        }

        private void RaiseEvent(string propertyName)
        {
            this.PropertyChanged?.Invoke(
                    this,
                    new PropertyChangedEventArgs(propertyName));
        }

        private void OnIncrementClick(object param)
        {
            ++this.Counter;
            this.CheckColor();
        }

        private void OnDecrementClick(object obj)
        {
            --this.Counter;
            this.CheckColor();
        }

        private void CheckColor()
        {
            if (this.Counter == DANGER_LIMIT)
            {
                this.CounterBackground = Brushes.Yellow;
            }
            else if(this.Counter > DANGER_LIMIT)
            {
                this.CounterBackground = Brushes.LightGreen;
            }
            else
            {
                this.CounterBackground = Brushes.Red;
            }
        }
    }
}
